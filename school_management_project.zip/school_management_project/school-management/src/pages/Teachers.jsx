function Teachers() {
    return <h2>Teachers List (Coming Soon)</h2>;
  }
  
  export default Teachers;
  