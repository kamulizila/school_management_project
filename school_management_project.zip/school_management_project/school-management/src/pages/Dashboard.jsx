function Dashboard() {
    return <h2>Welcome to the School Management System</h2>;
  }
  
  export default Dashboard;
  